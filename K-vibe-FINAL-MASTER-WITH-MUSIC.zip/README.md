# K-vibe — consolidated publish/test build

This build consolidates the K-vibe features requested during development.

## Included
- Welcome → automatic auth flow with working Continue button
- Supabase sign-in, sign-up, email verification callback, and guest entry
- Home video feed, video detail, likes, comments, shares, views and watch progress
- Creator profiles, follow/unfollow, profile videos and search
- Upload video from phone gallery
- Record video with camera/microphone
- Camera filters: Normal, Beauty, B&W, Sepia, Vintage, Vivid, Cool, Warm
- Brightness, contrast and saturation controls + front/rear camera switch
- Live streaming using WebRTC + Supabase Realtime signaling, discovery, heartbeat and viewer connections
- Notifications and realtime notifications
- Direct messages and realtime messaging
- Settings and account deletion
- Creator Studio analytics
- Moderator center and moderation data flows
- Paid Ad requests backed by `promotion_orders` (manual payment verification before publishing)
- Paid Boast requests backed by `promotion_orders` (manual payment verification before publishing)
- Data-saving feed: lazy video loading and no full-feed rerender after likes/saves/shares

## Supabase
Project: `syipuoxbxckrphhlakol`
The public frontend uses the publishable key only; no service-role key is included.

## Live streaming note
The live implementation is peer-to-peer WebRTC. It is suitable for testing/small usage but is not a TikTok-scale media-server architecture.

## Deployment
Upload the contents of this ZIP as a fresh Netlify deploy.

## Video pipeline v2
- New uploads are optimized in the browser before Storage upload when they are large/high-resolution.
- Playback targets MP4/H.264/AAC at up to 720px wide, with fast-start enabled.
- Large uploads continue to use resumable TUS upload after optimization.
- The feed loads only the currently visible video and does not preload metadata for the whole feed.
- The optimizer is loaded only when an uploaded video actually needs optimization.

Note: videos already stored before this pipeline was added remain in their original format until they are migrated.


## v5 audio auth behavior
- Feed audio stays muted before authentication and in guest mode.
- After a valid Supabase session is confirmed, the existing audio-unlock behavior is enabled.
- Signing out immediately pauses and mutes feed videos.


## Video data optimization v6
- Feed loads only the visible video and unloads offscreen media after 8 seconds when Data Saver/network save-data is active.
- Data Saver is enabled by default for new settings records.
- Creator Studio includes a one-time optimizer for older large videos; it downloads, compresses to the mobile MP4 pipeline, uploads the optimized copy, and switches playback to it without deleting the original.
- New uploads continue through the browser optimizer before Storage upload.
