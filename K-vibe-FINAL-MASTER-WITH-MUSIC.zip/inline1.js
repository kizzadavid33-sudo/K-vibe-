
(function(){
  const SUPABASE_URL='https://syipuoxbxckrphhlakol.supabase.co';
  const SUPABASE_KEY='sb_publishable_fwHXlOp6b8F6w2swc1Cgdw_RA-nIG_1';
  const nav=document.querySelector('[data-bottom-nav]');
  const welcome=document.querySelector('[data-welcome]');
  const auth=document.querySelector('[data-auth]');
  const main=document.querySelector('[data-main]');
  const screens=[...document.querySelectorAll('[data-screen]')];
  const form=document.querySelector('[data-auth-form]');
  const modeEl=form?.querySelector('[data-auth-mode]');
  const status=form?.querySelector('[data-auth-status]');
  const emailEl=form?.querySelector('[data-auth-email]');
  const passwordEl=form?.querySelector('[data-auth-password]');
  const usernameEl=form?.querySelector('[data-auth-username]');
  const displayEl=form?.querySelector('[data-auth-display-name]');
  const toggle=form?.querySelector('[data-auth-toggle]');
  const guest=form?.querySelector('[data-auth-guest]');
  const submit=form?.querySelector('[data-auth-submit]');
  const welcomeContinue=document.querySelector('[data-welcome-continue]');
  let welcomeTimer=null;

  function setAuthMode(mode){
    if(!form)return;
    modeEl.value=mode;
    const signup=mode==='signup';
    usernameEl.hidden=!signup; displayEl.hidden=!signup;
    usernameEl.required=signup;
    form.querySelector('[data-auth-title]').textContent=signup?'Create your K-vibe account':'Sign in to K-vibe';
    submit.textContent=signup?'Create account':'Sign in';
    toggle.textContent=signup?'I already have an account':'Create an account';
    passwordEl.autocomplete=signup?'new-password':'current-password';
    if(status)status.textContent='';
  }

  function enterApp(route='home', replace=false){
    clearTimeout(welcomeTimer);
    welcome?.setAttribute('hidden','');
    auth?.setAttribute('hidden','');
    main?.removeAttribute('hidden');
    nav?.removeAttribute('hidden');
    screens.forEach(s=>{s.hidden=s.getAttribute('data-screen')!==route});
    const hash='#/'+route;
    if(location.hash!==hash){
      if(replace)history.replaceState({kvibe:true},'',hash); else history.pushState({kvibe:true},'',hash);
    }
    window.scrollTo(0,0);
    window.dispatchEvent(new CustomEvent('k-vibe:route-changed',{detail:{current:route,params:{}}}));
  }

  function showAuth(){
    main?.setAttribute('hidden','');
    nav?.setAttribute('hidden','');
    welcome?.removeAttribute('hidden');
    document.querySelector('[data-welcome-hero]')?.setAttribute('hidden','');
    auth?.removeAttribute('hidden');
    setAuthMode('signup');
    window.scrollTo(0,0);
  }

  function showRoute(route, push=true){
    if(!route||route==='landing'){showAuth();return;}
    enterApp(route,!push);
  }

  function handleNav(e){
    const b=e.target.closest?.('[data-nav-route],[data-create-button]');
    if(!b)return;
    e.preventDefault(); e.stopPropagation();
    const route=b.hasAttribute('data-create-button')?'create':b.getAttribute('data-nav-route');
    if(route)showRoute(route,true);
  }
  document.addEventListener('click',handleNav,true);
  document.addEventListener('pointerup',handleNav,true);
  document.addEventListener('touchend',handleNav,true);

  // Create-panel UI fallback: switching Upload / Record / Live must work even if a
  // secondary module is delayed. The feature controller still owns the actual camera/upload work.
  function showCreatePanel(mode){
    if(location.hash.replace(/^#\/?/,'').split('?')[0]!=='create')return;
    const upload=document.querySelector('[data-upload-panel]'), record=document.querySelector('[data-record-panel]'), live=document.querySelector('[data-live-panel]');
    if(upload)upload.hidden=mode!=='upload'; if(record)record.hidden=mode!=='record'; if(live)live.hidden=mode!=='live';
  }
  document.addEventListener('click',e=>{
    const b=e.target.closest?.('[data-create-upload-tab],[data-create-record-tab],[data-create-live-tab]'); if(!b)return;
    if(b.hasAttribute('data-create-upload-tab'))showCreatePanel('upload');
    else if(b.hasAttribute('data-create-record-tab'))showCreatePanel('record');
    else showCreatePanel('live');
  });

  toggle?.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();setAuthMode(modeEl.value==='signin'?'signup':'signin');});
  guest?.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();enterApp('home');});
  welcomeContinue?.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();showAuth();});

  async function getClient(){
    if(globalThis.__kvibeSupabaseClient)return globalThis.__kvibeSupabaseClient; if(globalThis.supabase?.createClient){globalThis.__kvibeSupabaseClient=globalThis.supabase.createClient(SUPABASE_URL,SUPABASE_KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true,storageKey:'kvibe-auth'}});return globalThis.__kvibeSupabaseClient;}
    throw new Error('K-vibe connection is still loading. Please try again in a moment.');
  }

  form?.addEventListener('submit',async function(e){
    e.preventDefault(); e.stopPropagation();
    if(status)status.textContent='';
    submit.disabled=true;
    try{
      const client=await getClient();
      const email=emailEl.value.trim(), password=passwordEl.value, mode=modeEl.value;
      if(mode==='signup'){
        const username=usernameEl.value.trim().toLowerCase();
        if(!/^[a-z0-9_]{3,30}$/.test(username))throw new Error('Username must be 3–30 characters using letters, numbers, or _.');
        const {data,error}=await client.auth.signUp({email,password,options:{data:{username,display_name:displayEl.value.trim()},emailRedirectTo:`${location.origin}/?auth=confirmed`}});
        if(error)throw error;
        if(data.session){
          window.dispatchEvent(new CustomEvent('k-vibe:auth-ready',{detail:{session:data.session}}));
          await client.from('profiles').update({username,display_name:displayEl.value.trim()||null}).eq('id',data.user.id).catch(()=>{});
          enterApp('home');
        }else{
          setAuthMode('signin');
          if(status)status.textContent='Account created. Check your email to confirm your account, then sign in.';
        }
      }else{
        const {data,error}=await client.auth.signInWithPassword({email,password});
        if(error)throw error;
        if(!data?.session)throw new Error('Sign in did not create a session. Please try again.');
        window.dispatchEvent(new CustomEvent('k-vibe:auth-ready',{detail:{session:data.session}}));
        enterApp('home');
      }
    }catch(err){
      if(status)status.textContent=err?.message||'Authentication failed.';
    }finally{submit.disabled=false;}
  });

  window.__kvibeFallbackNav={showApp:enterApp,showScreen:enterApp,goToAuth:showAuth,enterApp};
  window.addEventListener('popstate',()=>{
    const raw=location.hash.replace(/^#\/?/,'');
    const route=raw.split('?')[0]||'landing';
    showRoute(route,false);
  });

  // Handle Supabase email-confirmation redirects. The confirmation link returns
  // to this same page; once the client exchanges the callback for a session,
  // send the user straight into the app instead of leaving them on the auth page.
  async function handleAuthCallback(){
    const query=new URLSearchParams(location.search);
    const hashParams=new URLSearchParams(location.hash.startsWith('#')?location.hash.slice(1):location.hash);
    const authError=query.get('error_description')||hashParams.get('error_description');
    if(authError){
      setAuthMode('signin');
      if(status)status.textContent=decodeURIComponent(authError.replace(/\+/g,' '));
      return false;
    }
    const isCallback=query.get('auth')==='confirmed'||query.has('code')||hashParams.has('access_token')||hashParams.has('refresh_token');
    if(!isCallback)return false;
    try{
      const client=await getClient();
      const {data,error}=await client.auth.getSession();
      if(error)throw error;
      if(data?.session){
        history.replaceState({},'',location.pathname);
        enterApp('home',true);
        return true;
      }
      setAuthMode('signin');
      if(status)status.textContent='Email confirmed. Please sign in with your email and password.';
      history.replaceState({},'',location.pathname);
      showAuth();
      return true;
    }catch(err){
      setAuthMode('signin');
      if(status)status.textContent=err?.message||'Email confirmation could not be completed. Please try again.';
      return true;
    }
  }

  const escapeHtml=v=>String(v??'').replace(/[&<>\"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]));
  const escapeAttr=v=>escapeHtml(v).replace(/`/g,'&#96;');
  async function getAuthenticatedClient(){
    const client=await getClient();
    const {data,error}=await client.auth.getUser();
    if(error)throw error;
    if(!data?.user)throw new Error('Please sign in before creating this.');
    return {client,user:data.user};
  }
  async function loadAdPosts(){
    const box=document.querySelector('[data-ad-list]'); if(!box)return;
    try{const client=await getClient();const {data,error}=await client.from('ad_posts').select('id,title,body,target_url,created_at').eq('status','published').order('created_at',{ascending:false}).limit(20);if(error)throw error;box.innerHTML=(data||[]).map(a=>`<article class="kv-card"><h3>${escapeHtml(a.title)}</h3><p>${escapeHtml(a.body||'')}</p>${a.target_url?`<a href="${escapeAttr(a.target_url)}" target="_blank" rel="noopener">Learn more</a>`:''}</article>`).join('')||'<p class="muted">No published ads yet.</p>'}catch(e){box.innerHTML='<p class="muted">Unable to load ads right now.</p>';console.warn(e)}}
  async function loadBoastPosts(){
    const box=document.querySelector('[data-boast-list]'); if(!box)return;
    try{const client=await getClient();const {data,error}=await client.from('boast_posts').select('id,title,body,created_at').order('created_at',{ascending:false}).limit(20);if(error)throw error;box.innerHTML=(data||[]).map(a=>`<article class="kv-card"><h3>${escapeHtml(a.title)}</h3><p>${escapeHtml(a.body||'')}</p></article>`).join('')||'<p class="muted">No boast posts yet.</p>'}catch(e){box.innerHTML='<p class="muted">Unable to load boast posts right now.</p>';console.warn(e)}}
  document.querySelector('[data-ad-form]')?.addEventListener('submit',async e=>{e.preventDefault();const s=document.querySelector('[data-ad-status]');const b=e.currentTarget.querySelector('button');try{b.disabled=true;s.textContent='Publishing ad…';const {client,user}=await getAuthenticatedClient();const title=document.querySelector('[data-ad-title]').value.trim(),body=document.querySelector('[data-ad-description]').value.trim(),target=document.querySelector('[data-ad-link]').value.trim()||null;const {error}=await client.from('ad_posts').insert({user_id:user.id,title,body:body||'Promoted on K-vibe',target_url:target,status:'published'});if(error)throw error;e.currentTarget.reset();s.textContent='Ad published successfully.';loadAdPosts()}catch(err){s.textContent=err.message||'Could not publish ad.'}finally{b.disabled=false}});
  document.querySelector('[data-boast-form]')?.addEventListener('submit',async e=>{e.preventDefault();const s=document.querySelector('[data-boast-status]');const b=e.currentTarget.querySelector('button');try{b.disabled=true;s.textContent='Publishing boast…';const {client,user}=await getAuthenticatedClient();const title=document.querySelector('[data-boast-title]').value.trim(),body=document.querySelector('[data-boast-text]').value.trim();const {error}=await client.from('boast_posts').insert({user_id:user.id,title,body});if(error)throw error;e.currentTarget.reset();s.textContent='Boast post published successfully.';loadBoastPosts()}catch(err){s.textContent=err.message||'Could not publish boast.'}finally{b.disabled=false}});
  addEventListener('k-vibe:route-changed',e=>{if(e.detail.current==='ads')loadAdPosts();if(e.detail.current==='boast')loadBoastPosts();});

  handleAuthCallback().then(handled=>{
    if(handled)return;
    if(!location.hash||location.hash==='#/'||location.hash==='#/landing'){
    nav?.setAttribute('hidden',''); main?.setAttribute('hidden',''); welcome?.removeAttribute('hidden');
    document.querySelector('[data-welcome-hero]')?.removeAttribute('hidden');
    auth?.setAttribute('hidden',''); setAuthMode('signup');
    clearTimeout(welcomeTimer); welcomeTimer=setTimeout(showAuth,900);
    }else{
      const route=location.hash.replace(/^#\/?/,'').split('?')[0];
      showRoute(route,false);
    }
  });
})();
