import{db,getDbClient}from'./supabase.js';let access=null;
export async function getSession(){
  const client=getDbClient();
  const {data,error}=await client.auth.getSession();
  if(error)throw error;
  return data?.session||null;
}
export async function getCurrentUser(){
  const session=await getSession();
  if(session?.user)return session.user;
  const {data,error}=await db.auth.getUser();
  if(error){if(error.message?.toLowerCase().includes('session missing'))return null;throw error}
  return data?.user||null;
}
export async function signIn(email,password){const{data,error}=await db.auth.signInWithPassword({email:email.trim(),password});if(error)throw error;return data}
export async function signUp(email,password,metadata={}){const{data,error}=await db.auth.signUp({email:email.trim(),password,options:{data:metadata}});if(error)throw error;return data}
export async function signOut(){const{error}=await db.auth.signOut();if(error)throw error;access=null}
export async function requestPasswordReset(email){const{error}=await db.auth.resetPasswordForEmail(email.trim(),{redirectTo:`${location.origin}/reset-password`});if(error)throw error}
export async function updatePassword(password){const{data,error}=await db.auth.updateUser({password});if(error)throw error;return data}
export async function updateEmail(email){const{data,error}=await db.auth.updateUser({email:email.trim()});if(error)throw error;return data}
export async function refreshAccessState(){const{data,error}=await db.rpc('get_account_access_state');if(error)throw error;access=data||null;return access}
export function getCachedAccessState(){return access}
export function isAccountDisabled(){return access?.disabled===true}
export function isAccountRestricted(){return access?.disabled===true||['limited','suspended'].includes(access?.restriction_type)}
export function canPublish(){return!isAccountRestricted()}
export function canInteract(){return!isAccountRestricted()}
export function canUseMessaging(){return!isAccountRestricted()}
export function subscribeToAuthChanges(cb){return db.auth.onAuthStateChange(cb)}
