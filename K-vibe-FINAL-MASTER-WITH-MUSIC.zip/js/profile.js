import{db}from'./supabase.js';
async function rpc(name,params={}){const{data,error}=await db.rpc(name,params);if(error)throw error;return data}
export const getFrontendCreatorProfile=username=>rpc('get_frontend_creator_profile',{p_username:username});
export const getCurrentCreatorProfile=async()=>rpc('get_my_profile');
export const getFrontendCreatorVideos=(userId,limit=20,offset=0)=>rpc('get_frontend_creator_videos',{p_user_id:userId,p_limit:limit,p_offset:offset});
export const getMyVideos=(limit=20,offset=0)=>rpc('get_my_videos',{p_limit:limit,p_offset:offset});
export const getFrontendCreatorFollowers=(userId,limit=50,offset=0)=>rpc('get_frontend_creator_followers',{p_user_id:userId,p_limit:limit,p_offset:offset});
export const getFrontendCreatorFollowing=(userId,limit=50,offset=0)=>rpc('get_frontend_creator_following',{p_user_id:userId,p_limit:limit,p_offset:offset});
export const getFrontendCreatorSuggestions=(limit=10)=>rpc('get_frontend_creator_suggestions',{p_limit:limit});
export const searchFrontendProfiles=(query,limit=30,offset=0)=>rpc('search_frontend_profiles',{p_query:query,p_limit:limit,p_offset:offset});
export const toggleCreatorFollow=userId=>rpc('toggle_creator_follow',{p_user_id:userId});
