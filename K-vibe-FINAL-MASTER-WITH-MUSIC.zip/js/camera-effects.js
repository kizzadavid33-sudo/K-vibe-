const FILTERS={
  normal:{name:'Normal',filter:'none'},
  beauty:{name:'Beauty',filter:'brightness(1.05) contrast(.96) saturate(1.06)'},
  bw:{name:'B&W',filter:'grayscale(1)'},
  sepia:{name:'Sepia',filter:'sepia(.85) saturate(1.12)'},
  vintage:{name:'Vintage',filter:'sepia(.25) contrast(.9) saturate(.78) brightness(1.04)'},
  vivid:{name:'Vivid',filter:'contrast(1.08) saturate(1.32)'},
  cool:{name:'Cool',filter:'contrast(1.03) saturate(.9) hue-rotate(8deg)'},
  warm:{name:'Warm',filter:'sepia(.12) saturate(1.12) hue-rotate(-8deg)'}
};

export function createCameraEffects(){
  let sourceStream=null, sourceVideo=null, canvas=null, ctx=null, processedStream=null, animation=null;
  let filter='normal', brightness=100, contrast=100, saturation=100, facingMode='user', running=false;

  const api={
    get stream(){return processedStream},
    get rawStream(){return sourceStream},
    get facingMode(){return facingMode},
    get filter(){return filter},
    get controls(){return {brightness,contrast,saturation}},
    async start(stream){
      await api.stop(); sourceStream=stream;
      sourceVideo=document.createElement('video'); sourceVideo.muted=true; sourceVideo.playsInline=true; sourceVideo.srcObject=stream;
      await sourceVideo.play().catch(()=>{});
      if(sourceVideo.readyState<2){await new Promise(resolve=>{let settled=false;const done=()=>{if(settled)return;settled=true;sourceVideo.removeEventListener('loadedmetadata',done);sourceVideo.removeEventListener('canplay',done);resolve()};sourceVideo.addEventListener('loadedmetadata',done,{once:true});sourceVideo.addEventListener('canplay',done,{once:true});setTimeout(done,1500)})}
      canvas=document.createElement('canvas'); canvas.width=Math.max(320,sourceVideo.videoWidth||720); canvas.height=Math.max(240,sourceVideo.videoHeight||1280);
      ctx=canvas.getContext('2d',{alpha:false});
      if(!ctx||typeof canvas.captureStream!=='function')throw new Error('Camera filters are not supported by this browser.');
      processedStream=canvas.captureStream(30);
      const audio=stream.getAudioTracks()[0]; if(audio) processedStream.addTrack(audio);
      running=true; draw(); return processedStream;
    },
    setFilter(name){if(FILTERS[name])filter=name},
    setBrightness(v){brightness=clamp(v,60,140)},
    setContrast(v){contrast=clamp(v,60,140)},
    setSaturation(v){saturation=clamp(v,0,180)},
    async switchCamera(){
      if(!sourceStream)return processedStream;
      facingMode=facingMode==='user'?'environment':'user';
      const old=sourceStream;
      const replacement=await navigator.mediaDevices.getUserMedia({video:{facingMode:{exact:facingMode},width:{ideal:1280},height:{ideal:720}},audio:false}).catch(async()=>navigator.mediaDevices.getUserMedia({video:{facingMode,width:{ideal:1280},height:{ideal:720}},audio:false}));
      const oldVideo=old.getVideoTracks()[0]; const newVideo=replacement.getVideoTracks()[0];
      if(oldVideo)newVideo.contentHint=oldVideo.contentHint||'motion';
      old.removeTrack?.(oldVideo); if(oldVideo)oldVideo.stop();
      sourceStream.addTrack(newVideo); sourceVideo.srcObject=sourceStream; await sourceVideo.play().catch(()=>{});
      return processedStream;
    },
    async stop(){
      running=false; if(animation)cancelAnimationFrame(animation); animation=null;
      if(processedStream){processedStream.getTracks().forEach(t=>{if(t.kind==='video'||t.kind==='audio')t.stop()});processedStream=null}
      if(sourceStream){sourceStream.getTracks().forEach(t=>t.stop());sourceStream=null}
      if(sourceVideo){sourceVideo.pause();sourceVideo.srcObject=null;sourceVideo=null}
      canvas=null;ctx=null;
    }
  };
  function draw(){
    if(!running||!ctx||!canvas)return;
    const f=FILTERS[filter]?.filter||'none';
    ctx.filter=`${f} brightness(${brightness/100}) contrast(${contrast/100}) saturate(${saturation/100})`;
    ctx.drawImage(sourceVideo,0,0,canvas.width,canvas.height); ctx.filter='none';
    animation=requestAnimationFrame(draw);
  }
  function clamp(v,min,max){return Math.min(max,Math.max(min,Number(v)||min))}
  return api;
}
export {FILTERS};
