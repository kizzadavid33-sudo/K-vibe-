import{getFeed,getFollowingFeed,recordFrontendVideoView,toggleVideoLike,recordFrontendVideoShare}from'./videos.js';
import{seedVideoEngagement,getVideoEngagement,incrementVideoViewCount,incrementVideoCommentCount}from'./video-engagement-state.js';
import{getFrontendVideoComments,createFrontendComment}from'./comments.js';
import{getSession}from'./auth.js';
import{goProfile}from'./router.js';
import{db}from'./supabase.js';
let initialized=false,videos=[],mode='for-you',offset=0;
const dataSaverEnabled=()=>localStorage.getItem('kvibe-data-saver')!=='0'||Boolean(navigator.connection?.saveData);

window.__kvibeAuthenticated=Boolean(window.__kvibeAuthenticated);
window.__kvibeAudioUnlocked=false;

// Hard safety net: no feed video may produce audible audio while the app is not signed in.
// Capture phase runs before the video's own play handler.
if(!window.__kvibeFeedPlayGuard){
 window.__kvibeFeedPlayGuard=true;
 document.addEventListener('play',e=>{
   const v=e.target;
   const homeVisible=Boolean(document.querySelector('[data-screen="home"]:not([hidden])'));
   if(v instanceof HTMLVideoElement && v.classList.contains('tiktok-video') && (!window.__kvibeAuthenticated||!homeVisible)){
     v.defaultMuted=true; v.muted=true; v.volume=0;
   }
 },true);
}

function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
function avatar(v){const u=v.avatar_url||v.user?.avatar_url;return u?`<img src="${esc(u)}" alt="" class="tiktok-avatar">`:'<span class="tiktok-avatar tiktok-avatar-fallback">K</span>'}
function count(n){n=Number(n||0);if(n>=1000000)return (n/1000000).toFixed(n%1000000?1:0)+'M';if(n>=1000)return (n/1000).toFixed(n%1000?1:0)+'K';return String(n)}
export async function loadFeed(){const root=document.querySelector('[data-feed]');if(!root)return;root.innerHTML='<div class="feed-loading">Loading your vibe…</div>';try{const session=await getSession().catch(()=>null);if(mode==='following'&&!session){mode='for-you';offset=0;videos=[]}const rows=mode==='following'?await getFollowingFeed(10,offset):await getFeed(10,offset);const list=Array.isArray(rows)?rows:(rows?.items||[]);videos=offset?videos.concat(list):list;list.forEach(v=>{const id=v?.id||v?.video_id;if(id)seedVideoEngagement({...v,id})});render(root);offset+=list.length}catch(e){root.innerHTML=`<div class="kv-error"><strong>Feed could not be loaded.</strong><p>${esc(e.message||'Please try again.')}</p><button type="button" data-feed-retry>Retry</button></div>`;root.querySelector('[data-feed-retry]')?.addEventListener('click',()=>loadFeed())}}
function render(root){root.innerHTML=videos.map((v,i)=>{const videoId=v.id||v.video_id;const s=getVideoEngagement(videoId);const liked=Boolean(s.liked_by_me||v.liked_by_me),saved=Boolean(s.saved_by_me||v.saved_by_me);const username=v.username||v.user?.username||'creator';return `<article class="tiktok-feed-card" data-card="${esc(videoId)}"><video class="tiktok-video" autoplay muted playsinline loop preload="none" data-video-src="${esc(v.video_url||'')}" data-video-id="${esc(videoId)}"></video><button class="tiktok-play-state" data-play-toggle="${esc(videoId)}" aria-label="Pause video"><span>▶</span></button><div class="tiktok-gradient"></div><div class="tiktok-overlay"><div class="tiktok-meta"><button class="tiktok-creator" data-creator="${esc(username)}">${avatar(v)} <strong>@${esc(username)}</strong></button><p>${esc(v.caption||'')}</p>${v.music_name?`<div class="tiktok-music">♫ ${esc(v.music_name)}</div>`:''}</div><div class="tiktok-actions"><button class="tiktok-action" data-like="${esc(videoId)}" aria-label="Like"><span class="tiktok-icon ${liked?'is-active':''}">♥</span><b>${count(s.likes??v.likes)}</b></button><button class="tiktok-action" data-comment="${esc(videoId)}" aria-label="Comments"><span class="tiktok-icon">💬</span><b>${count(s.comments??v.comments)}</b></button><button class="tiktok-action" data-save="${esc(videoId)}" aria-label="Save"><span class="tiktok-icon ${saved?'is-active':''}">🔖</span><b>${saved?'Saved':'Save'}</b></button><button class="tiktok-action" data-share="${esc(videoId)}" aria-label="Share"><span class="tiktok-icon">↗</span><b>${count(s.shares??v.shares)}</b></button><button class="tiktok-avatar-action" data-creator="${esc(username)}" aria-label="Creator">${avatar(v)}</button></div></div><div class="tiktok-views">${count(s.views??v.views)} views</div><div class="tiktok-comments-sheet" data-comments-box="${esc(videoId)}" hidden></div></article>`}).join('')||'<div class="feed-empty"><strong>No videos yet.</strong><p>Be the first to post your vibe.</p></div>';
root.querySelectorAll('.tiktok-video').forEach(video=>{video.autoplay=true;video.defaultMuted=true;video.muted=true;video.volume=0;video.setAttribute('autoplay','');video.setAttribute('muted','');video.setAttribute('playsinline','');video.removeAttribute('src');video.addEventListener('play',()=>{const homeVisible=Boolean(document.querySelector('[data-screen="home"]:not([hidden])'));if(!window.__kvibeAuthenticated||!homeVisible){video.defaultMuted=true;video.muted=true;video.volume=0;}else applyFeedAudio(video);window.__kvibeActiveFeedVideo=video;stopOtherFeedVideos(video);video.closest('.tiktok-feed-card')?.classList.add('is-playing');view(video.dataset.videoId)});video.addEventListener('error',()=>{const card=video.closest('.tiktok-feed-card');card?.classList.add('video-load-error');const play=card?.querySelector('.tiktok-play-state');if(play){play.querySelector('span').textContent='!';play.setAttribute('aria-label','Video could not be loaded');}});video.addEventListener('pause',()=>video.closest('.tiktok-feed-card')?.classList.remove('is-playing'));video.addEventListener('click',()=>{if(video.paused){video.dataset.manualPause='0';if(window.__kvibeAuthenticated&&document.querySelector('[data-screen="home"]:not([hidden])')){window.__kvibeAudioUnlocked=true;applyFeedAudio(video);}else{video.defaultMuted=true;video.muted=true;video.volume=0;stopOtherFeedVideos(video);}video.play().catch(()=>{})}else{video.dataset.manualPause='1';video.pause()}})});root.querySelectorAll('[data-play-toggle]').forEach(b=>b.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();const v=b.closest('.tiktok-feed-card')?.querySelector('.tiktok-video');if(!v)return;if(v.paused){v.dataset.manualPause='0';if(window.__kvibeAuthenticated&&document.querySelector('[data-screen="home"]:not([hidden])')){window.__kvibeAudioUnlocked=true;applyFeedAudio(v);}else{v.defaultMuted=true;v.muted=true;v.volume=0;stopOtherFeedVideos(v);}v.play().catch(()=>{})}else{v.dataset.manualPause='1';v.pause()}}));
root.querySelectorAll('[data-like]').forEach(b=>b.onclick=e=>{e.preventDefault();e.stopPropagation();actLike(b.dataset.like)});root.querySelectorAll('[data-comment]').forEach(b=>b.onclick=e=>{e.preventDefault();e.stopPropagation();toggleComments(b.dataset.comment)});root.querySelectorAll('[data-save]').forEach(b=>b.onclick=e=>{e.preventDefault();e.stopPropagation();actSave(b.dataset.save)});root.querySelectorAll('[data-share]').forEach(b=>b.onclick=e=>{e.preventDefault();e.stopPropagation();share(b.dataset.share)});root.querySelectorAll('[data-creator]').forEach(b=>b.onclick=e=>{e.preventDefault();e.stopPropagation();b.dataset.creator&&goProfile(b.dataset.creator)});
observeFeedVideos(root);}
async function toggleComments(id){
  const card=document.querySelector(`[data-card="${CSS.escape(id)}"]`);
  const box=card?.querySelector(`[data-comments-box="${CSS.escape(id)}"]`);
  if(!box)return;
  if(!box.hidden){box.hidden=true;return;}
  box.hidden=false;
  box.innerHTML='<div class="comments-head"><strong>Comments</strong><button type="button" data-close-comments aria-label="Close comments">×</button></div><div class="comments-list">Loading…</div><form><input maxlength="1000" placeholder="Add a comment…" required><button type="submit">Post</button></form>';
  box.querySelector('[data-close-comments]').onclick=()=>{box.hidden=true};
  const list=box.querySelector('.comments-list');
  try{
    const r=await getFrontendVideoComments(id);
    const rows=Array.isArray(r)?r:(r?.items||[]);
    list.innerHTML=rows.map(c=>`<p><b>@${esc(c.username||c.user?.username||'user')}</b> ${esc(c.text||'')}</p>`).join('')||'<p class="muted">No comments yet.</p>';
  }catch(e){
    const msg=String(e?.message||'');
    list.innerHTML=`<p class="muted">${esc(msg||'Could not load comments.')}</p>`;
  }
  box.querySelector('form').onsubmit=async e=>{
    e.preventDefault();
    const input=e.currentTarget.querySelector('input');
    const text=input.value.trim();
    if(!text)return;
    const submit=e.currentTarget.querySelector('button');
    submit.disabled=true;
    try{
      if(!await requireAuth())return;
      await createFrontendComment(id,text);
      input.value='';
      incrementVideoCommentCount(id);
      const r=await getFrontendVideoComments(id);
      const rows=Array.isArray(r)?r:(r?.items||[]);
      list.innerHTML=rows.map(c=>`<p><b>@${esc(c.username||c.user?.username||'user')}</b> ${esc(c.text||'')}</p>`).join('')||'<p class="muted">No comments yet.</p>';
      const countEl=card?.querySelector(`[data-comment="${CSS.escape(id)}"] b`);
      if(countEl)countEl.textContent=count(getVideoEngagement(id).comments);
    }catch(e){alert(e?.message||'Could not post comment.')}finally{submit.disabled=false}
  };
}
function getActiveFeedVideo(){
 const marked=document.querySelector('.tiktok-feed-card.is-playing .tiktok-video');
 if(marked)return marked;
 const visible=[...document.querySelectorAll('.tiktok-feed-card')].map(card=>{
   const r=card.getBoundingClientRect();
   const visiblePx=Math.max(0,Math.min(r.bottom,innerHeight)-Math.max(r.top,0));
   return {video:card.querySelector('.tiktok-video'),visiblePx};
 }).filter(x=>x.video&&x.visiblePx>0).sort((a,b)=>b.visiblePx-a.visiblePx)[0];
 return visible?.video||null;
}
function stopOtherFeedVideos(active){
 document.querySelectorAll('.tiktok-feed-card .tiktok-video').forEach(v=>{
   if(v===active)return;
   try{v.pause()}catch{}
   v.defaultMuted=true;
   v.muted=true;
   v.volume=0;
   v.closest('.tiktok-feed-card')?.classList.remove('is-playing');
 });
}
function applyFeedAudio(video){
 if(!video)return;
 const unlocked=Boolean(window.__kvibeAuthenticated&&window.__kvibeAudioUnlocked);
 stopOtherFeedVideos(video);
 video.defaultMuted=!unlocked;
 video.muted=!unlocked;
 video.volume=unlocked?1:0;
}
async function unlockFeedAudio(){
 if(!window.__kvibeAuthenticated)return;
 if(!document.querySelector('[data-screen="home"]:not([hidden])'))return;
 const session=await getSession().catch(()=>null);
 if(!session){window.__kvibeAuthenticated=false;window.__kvibeAudioUnlocked=false;stopFeedMedia();return;}
 window.__kvibeAudioUnlocked=true;
 const active=getActiveFeedVideo();
 if(active){
   applyFeedAudio(active);
   active.play().catch(()=>{});
 }
}
if(!window.__kvibeFeedAudioListener){
 window.__kvibeFeedAudioListener=true;
 document.addEventListener('pointerdown',e=>{
   if(window.__kvibeAuthenticated && (location.hash.startsWith('#/home')||document.querySelector('[data-screen="home"]:not([hidden])'))) unlockFeedAudio();
 },{capture:true,passive:true});
 document.addEventListener('keydown',()=>{if(window.__kvibeAuthenticated&&location.hash.startsWith('#/home'))unlockFeedAudio();},{capture:true,passive:true});
 addEventListener('k-vibe:auth-ready',e=>{
   const authenticated=Boolean(e.detail?.session);
   window.__kvibeAuthenticated=authenticated;
   if(!authenticated){
     window.__kvibeAudioUnlocked=false;
     window.__kvibeActiveFeedVideo=null;
     document.querySelectorAll('.tiktok-video').forEach(v=>{v.pause();v.defaultMuted=true;v.muted=true;v.volume=0;});
     return;
   }
   // Authentication never grants audible autoplay by itself. Start the active video muted.
   setTimeout(ensureHomeAutoplay,120);
 });
}
function observeFeedVideos(root){
 const cards=[...root.querySelectorAll('.tiktok-feed-card')];
 const unloadTimers=new WeakMap();
 const playActive=async(v)=>{
   if(!v||window.__kvibeActiveFeedVideo!==v)return false;
   if(!v.src && v.dataset.videoSrc){v.src=v.dataset.videoSrc;v.preload='auto';v.load();}
   v.autoplay=true;
   v.defaultMuted=true;
   v.muted=true;
   v.volume=0;
   if(window.__kvibeAuthenticated&&window.__kvibeAudioUnlocked&&document.querySelector('[data-screen="home"]:not([hidden])'))applyFeedAudio(v);
   else {v.defaultMuted=true;v.muted=true;v.volume=0;}
   stopOtherFeedVideos(v);
   try{await v.play();return true}catch(_){
     // Muted autoplay is the required baseline. Retry once after the browser has had a frame.
     if(window.__kvibeActiveFeedVideo!==v)return false;
     v.defaultMuted=true;v.muted=true;v.volume=0;
     await new Promise(r=>requestAnimationFrame(()=>r()));
     try{await v.play();return true}catch(_2){return false}
   }
 };
 const load=async(v,play=false)=>{
   if(!v||!v.dataset.videoSrc)return;
   const timer=unloadTimers.get(v);if(timer){clearTimeout(timer);unloadTimers.delete(v)}
   v.autoplay=true;v.defaultMuted=true;v.muted=true;v.volume=0;
   if(!v.src){v.src=v.dataset.videoSrc;v.preload='auto';v.load()}
   if(play){
     const attempt=()=>{if(window.__kvibeActiveFeedVideo===v)playActive(v)};
     if(v.readyState>=2)attempt();
     else {v.addEventListener('loadeddata',attempt,{once:true});v.addEventListener('canplay',attempt,{once:true});}
     // Always make an immediate attempt; muted autoplay is allowed by modern mobile browsers.
     playActive(v);
   }
 };
 const unloadLater=(v)=>{
   if(!dataSaverEnabled()||!v?.src)return;
   const timer=setTimeout(()=>{
     if(!v.paused)return;
     v.pause();v.removeAttribute('src');v.load();
   },8000);
   unloadTimers.set(v,timer);
 };
 const activate=(video)=>{
   if(!video)return;
   window.__kvibeActiveFeedVideo=video;
   stopOtherFeedVideos(video);
   load(video,true);
 };
 const first=cards[0]?.querySelector('video');
 if(first)activate(first);
 if(!('IntersectionObserver'in window))return;
 const io=new IntersectionObserver(entries=>entries.forEach(e=>{
   const card=e.target,video=card.querySelector('video');if(!video)return;
   const index=cards.indexOf(card);
   if(e.isIntersecting&&e.intersectionRatio>.35){
     activate(video);
     cards.forEach((c,i)=>{if(i!==index){const other=c.querySelector('video');if(other)unloadLater(other)}});
   }else if(!e.isIntersecting){
     if(window.__kvibeActiveFeedVideo===video)window.__kvibeActiveFeedVideo=null;
     video.pause();video.defaultMuted=true;video.muted=true;video.volume=0;
     video.closest('.tiktok-feed-card')?.classList.remove('is-playing');
     unloadLater(video);
   }
 }),{rootMargin:'0px',threshold:[.35,.6]});
 cards.forEach(c=>io.observe(c));
}
function ensureHomeAutoplay(){
 if(!document.querySelector('[data-screen="home"]:not([hidden])'))return;
 const active=getActiveFeedVideo()||document.querySelector('.tiktok-feed-card .tiktok-video');
 if(!active)return;
 active.dataset.manualPause='0';
 window.__kvibeActiveFeedVideo=active;
 active.defaultMuted=true;active.muted=true;active.volume=0;
 if(!active.src&&active.dataset.videoSrc){active.src=active.dataset.videoSrc;active.preload='auto';active.load();}
 const run=()=>{if(window.__kvibeActiveFeedVideo!==active)return;active.play().catch(()=>{setTimeout(()=>active.play().catch(()=>{}),250)})};
 if(active.readyState>=2)run(); else {active.addEventListener('canplay',run,{once:true});setTimeout(run,250);}
}
async function view(id){try{await recordFrontendVideoView(id);incrementVideoViewCount(id)}catch{}}
async function requireAuth(){
  const session=await getSession().catch(()=>null);
  if(session)return true;
  if(window.__kvibeFallbackNav?.goToAuth){window.__kvibeFallbackNav.goToAuth();}else{location.hash='#/landing';}
  return false;
}
async function actLike(id){
 if(!id)return;
 try{
  if(!await requireAuth())return;
  const r=await toggleVideoLike(id), s=getVideoEngagement(id);
  if(typeof r==='boolean'){s.liked_by_me=r;s.likes=Math.max(0,Number(s.likes||0)+(r?1:-1))}
  else if(r&&typeof r==='object')Object.assign(s,r);
  const card=document.querySelector(`[data-card="${CSS.escape(id)}"]`);
  const btn=card?.querySelector(`[data-like="${CSS.escape(id)}"]`);
  if(btn){btn.querySelector('.tiktok-icon')?.classList.toggle('is-active',!!s.liked_by_me);const b=btn.querySelector('b');if(b)b.textContent=count(s.likes)}
 }catch(e){alert(e.message)}
}
async function actSave(id){
 if(!id)return;
 try{
  if(!await requireAuth())return;
  const{data,error}=await db.rpc('toggle_video_save',{p_video_id:id});if(error)throw error;
  const s=getVideoEngagement(id);s.saved_by_me=Boolean(data);s.saves=Math.max(0,Number(s.saves||0)+(data?1:-1));
  const card=document.querySelector(`[data-card="${CSS.escape(id)}"]`);
  const btn=card?.querySelector(`[data-save="${CSS.escape(id)}"]`);
  if(btn){btn.querySelector('.tiktok-icon')?.classList.toggle('is-active',!!s.saved_by_me);const b=btn.querySelector('b');if(b)b.textContent=s.saved_by_me?'Saved':'Save'}
 }catch(e){alert(e.message)}
}
async function share(id){
 if(!id)return;
 try{
  if(!await requireAuth())return;
  const r=await recordFrontendVideoShare(id),s=getVideoEngagement(id);
  if(typeof r==='boolean'){s.shared_by_me=r;s.shares=Math.max(0,Number(s.shares||0)+(r?1:0))}
  else if(r&&typeof r==='object')Object.assign(s,r);
  if(navigator.share)await navigator.share({title:'K-vibe',text:'Check out this vibe on K-vibe',url:`${location.href.split('#')[0]}#/video?videoId=${encodeURIComponent(id)}`}).catch(()=>{});
  const card=document.querySelector(`[data-card="${CSS.escape(id)}"]`),btn=card?.querySelector(`[data-share="${CSS.escape(id)}"]`);if(btn){const b=btn.querySelector('b');if(b)b.textContent=count(s.shares)}
 }catch(e){alert(e.message)}
}
export function stopFeedMedia(){
  window.__kvibeActiveFeedVideo=null;
  document.querySelectorAll('video,audio').forEach(media=>{
    try{media.pause()}catch{}
    try{media.currentTime=0}catch{}
    try{media.defaultMuted=true;media.muted=true;media.volume=0}catch{}
    try{media.removeAttribute('src');media.load()}catch{}
  });
  document.querySelectorAll('.tiktok-feed-card.is-playing').forEach(card=>card.classList.remove('is-playing'));
}
addEventListener('k-vibe:route-changed',e=>{
 if(e.detail?.current!=='home'){window.__kvibeAudioUnlocked=false;stopFeedMedia();}
 else setTimeout(ensureHomeAutoplay,120);
});
addEventListener('pagehide',stopFeedMedia);
addEventListener('visibilitychange',()=>{if(document.hidden)stopFeedMedia()});
export function setFeedMode(next){mode=next;offset=0;videos=[];loadFeed()}export function initializeFeedController(){if(initialized)return;initialized=true;addEventListener('k-vibe:video-published',()=>{offset=0;videos=[];loadFeed()});addEventListener('k-vibe:auth-ready',()=>{offset=0;videos=[];loadFeed()});loadFeed();setTimeout(ensureHomeAutoplay,250)}export function cleanupFeedController(){initialized=false;videos=[];offset=0}
