const SUPABASE_URL='https://syipuoxbxckrphhlakol.supabase.co';
const SUPABASE_PUBLISHABLE_KEY='sb_publishable_fwHXlOp6b8F6w2swc1Cgdw_RA-nIG_1';
let dbClient=globalThis.__kvibeSupabaseClient||null;
function getDb(){
  if(dbClient)return dbClient;
  const sdk=globalThis.supabase;
  if(!sdk?.createClient)throw new Error('K-vibe connection is still loading. Please try again in a moment.');
  dbClient=sdk.createClient(SUPABASE_URL,SUPABASE_PUBLISHABLE_KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true,storageKey:'kvibe-auth'}});
  globalThis.__kvibeSupabaseClient=dbClient;
  return dbClient
}
export const db=new Proxy({}, {get(_t,p){const v=getDb()[p];return typeof v==='function'?v.bind(getDb()):v}});
export {SUPABASE_URL,SUPABASE_PUBLISHABLE_KEY};
export function getDbClient(){return getDb()}
