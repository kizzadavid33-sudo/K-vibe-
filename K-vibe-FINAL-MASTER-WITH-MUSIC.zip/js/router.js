export const ROUTES=Object.freeze({LANDING:'landing',HOME:'home',SEARCH:'search',CREATE:'create',NOTIFICATIONS:'notifications',MESSAGES:'messages',PROFILE:'profile',VIDEO:'video',SETTINGS:'settings',MODERATOR:'moderator',CREATOR_DASHBOARD:'creator-dashboard',ADS:'ads',BOAST:'boast'});
let state={current:null,previous:null,params:{}};
export function getCurrentRoute(){return{...state,params:{...state.params}}}
function valid(route){return Boolean(ROUTES[route?.toUpperCase()]||Object.values(ROUTES).includes(route))}
function renderRoute(route){
  const landing=route===ROUTES.LANDING;
  document.querySelector('[data-welcome]')?.toggleAttribute('hidden',!landing);
  document.querySelector('[data-main]')?.toggleAttribute('hidden',landing);
  document.querySelector('[data-bottom-nav]')?.toggleAttribute('hidden',landing);
  document.querySelectorAll('[data-screen]').forEach(el=>{el.hidden=el.getAttribute('data-screen')!==route});
  if(landing){document.querySelector('[data-auth]')?.removeAttribute('hidden');}
  else{document.querySelector('[data-auth]')?.setAttribute('hidden','');}
  if(!landing)window.scrollTo({top:0,behavior:'instant'});
}
export function navigate(route,params={},options={}){
  if(!valid(route))throw Error('Unknown route');
  document.querySelectorAll('video,audio').forEach(m=>{try{m.pause();m.currentTime=0;}catch{}});
  state={current:route,previous:state.current,params:{...params}};
  const q=new URLSearchParams(Object.entries(params).filter(([,v])=>v!==undefined&&v!==null&&v!==''));
  const hash=`#/${route}${q.toString()?`?${q}`:''}`;
  if(location.hash!==hash){ if(options.replace) history.replaceState({},'',hash); else history.pushState({},'',hash); }
  renderRoute(route);
  dispatchEvent(new CustomEvent('k-vibe:route-changed',{detail:getCurrentRoute()}));
  dispatchEvent(new CustomEvent(`k-vibe:screen-${route}`,{detail:params}));
}
export const goHome=()=>navigate('home');
export const goSearch=q=>navigate('search',{query:q||''});
export const goCreate=()=>navigate('create');
export const goNotifications=()=>navigate('notifications');
export const goMessages=userId=>navigate('messages',userId?{userId}:{});
export const goProfile=username=>navigate('profile',username?{username}:{});
export const goVideo=videoId=>navigate('video',{videoId});
export const goSettings=()=>navigate('settings');
export const goModerator=()=>navigate('moderator');
export const goCreatorDashboard=period=>navigate('creator-dashboard',period?{period}:{});
export function initializeRouter(){
  const raw=location.hash.replace(/^#\/?/,'');
  if(!raw){navigate('landing',{}, {replace:true});return;}
  const [path,query='']=raw.split('?');
  navigate(path,Object.fromEntries(new URLSearchParams(query)),{replace:true});
}
export function cleanupRouter(){}
addEventListener('popstate',()=>{const raw=location.hash.replace(/^#\/?/,'');const [path='landing',query='']=raw.split('?');navigate(path||'landing',Object.fromEntries(new URLSearchParams(query)),{replace:true})});
