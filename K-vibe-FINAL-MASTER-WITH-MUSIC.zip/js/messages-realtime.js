import{db}from'./supabase.js';
import{removeRealtimeChannel}from'./realtime.js';
let channel=null;
export function subscribeToMessageRealtime(userId,handler){
  if(!userId)return null;
  cleanupMessageRealtime();
  channel=db.channel(`messages:${userId}`)
    .on('postgres_changes',{event:'INSERT',schema:'public',table:'messages',filter:`recipient_id=eq.${userId}`},p=>handler(p.new))
    .on('postgres_changes',{event:'INSERT',schema:'public',table:'messages',filter:`sender_id=eq.${userId}`},p=>handler(p.new));
  channel.subscribe();
  return channel;
}
export function cleanupMessageRealtime(){
  if(channel){db.removeChannel(channel);channel=null;}
  removeRealtimeChannel('messages');
}
