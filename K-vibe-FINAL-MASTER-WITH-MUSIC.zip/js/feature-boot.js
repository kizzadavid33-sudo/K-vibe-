import{initializeCreateController}from'./create-controller.js?v=20261003.1';
import{initializeLiveController}from'./live-controller.js';
import{initializeProfileController}from'./profile-controller.js';
import{initializeYoVibeController}from'./yo-vibe-controller.js';
function start(){
  const run=(name,fn)=>{try{fn()}catch(e){console.error('K-vibe '+name+' controller failed',e);}};
  run('create',initializeCreateController);
  run('live',initializeLiveController);
  run('profile',initializeProfileController);
  run('yo-vibe',initializeYoVibeController);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
setTimeout(start,500);
