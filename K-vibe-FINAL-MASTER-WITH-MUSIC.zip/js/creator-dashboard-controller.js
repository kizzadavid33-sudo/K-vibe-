import{getMyVideos}from'./profile.js?v=20261003.2';
import{optimizeVideo}from'./create-controller.js?v=20261003.1';
import{db}from'./supabase.js';
import{getSession}from'./auth.js';
async function rpc(n,p={}){const{data,error}=await db.rpc(n,p);if(error)throw error;return data}
export const getCreatorDashboardOverview=days=>rpc('get_my_creator_dashboard_overview',{p_period_days:days});
export const getCreatorDailyAnalytics=days=>rpc('get_my_daily_analytics',{p_days:days});
export const getAudienceSnapshot=days=>rpc('get_my_audience_snapshot',{p_period_days:days});
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num=v=>new Intl.NumberFormat().format(Number(v)||0);
function metric(label,value,sub=''){return `<div class="studio-metric"><strong>${num(value)}</strong><span>${esc(label)}</span>${sub?`<small>${esc(sub)}</small>`:''}</div>`}
function render(root,daily,audience){
 const c=daily?.overview?.current||daily?.current||{};
 const a=audience||{};
 const metrics=root.querySelector('[data-dashboard-metrics]');
 if(metrics)metrics.innerHTML=`<div class="studio-metrics-grid">${metric('Views',c.views)}${metric('Likes',c.likes)}${metric('Comments',c.comments)}${metric('Shares',c.shares)}${metric('Watchers',c.watchers)}${metric('Completed views',c.completed_views)}${metric('Followers gained',c.followers_gained)}${metric('Videos published',c.videos_published)}</div>`;
 const aud=root.querySelector('[data-audience-metrics]');
 if(aud)aud.innerHTML=`<div class="studio-section"><div class="studio-section-head"><div><span class="eyebrow">AUDIENCE</span><h2>People finding your vibe</h2></div></div><div class="studio-audience-grid">${metric('Followers',a.followers)}${metric('Following',a.following)}${metric('Gained in 30 days',a.followers_gained)}</div></div>`;
 const chart=root.querySelector('[data-performance-chart]');
 const rows=Array.isArray(daily?.days)?daily.days:Array.isArray(daily)?daily:[];
 if(chart){const max=Math.max(1,...rows.map(x=>Number(x.views)||0));chart.innerHTML=`<div class="studio-section"><div class="studio-section-head"><div><span class="eyebrow">LAST 7 DAYS</span><h2>Performance</h2></div></div><div class="studio-chart">${rows.map(x=>{const h=Math.max(4,Math.round(((Number(x.views)||0)/max)*100));const day=new Date(`${x.day}T00:00:00`).toLocaleDateString([], {weekday:'short'});return `<div class="studio-bar-wrap"><div class="studio-bar" style="height:${h}%" title="${num(x.views)} views"></div><small>${esc(day)}</small><b>${num(x.views)}</b></div>`}).join('')||'<p class="muted">Your daily performance will appear here after people watch your videos.</p>'}</div></div>`}
}
async function optimizeExistingVideos(){
 const button=document.querySelector('[data-optimize-existing-videos]'),status=document.querySelector('[data-optimize-status]');
 if(!button)return;
 button.disabled=true;
 try{
   const session=await getSession();if(!session?.user)throw Error('Please sign in first.');
   const rows=await getMyVideos(50,0);const list=Array.isArray(rows)?rows:(rows?.items||[]);
   if(!list.length){if(status)status.textContent='No videos found to optimize.';return;}
   let changed=0;
   for(let i=0;i<list.length;i++){
     const v=list[i];if(!v?.video_url)continue;
     if(status)status.textContent=`Optimizing video ${i+1} of ${list.length}…`;
     const res=await fetch(v.video_url,{mode:'cors'});if(!res.ok)throw Error(`Could not download video ${i+1} (${res.status}).`);
     const blob=await res.blob();const file=new File([blob],`kvibe-${v.id}.mp4`,{type:blob.type||'video/mp4'});
     const meta={durationSeconds:Number(v.duration_seconds)||null,width:Number(v.width)||0,height:Number(v.height)||0};
     const optimized=await optimizeVideo(file,meta);
     if(optimized.size>=file.size&&file.size<=20*1024*1024)continue;
     const path=`optimized/${session.user.id}/${v.id}-${Date.now()}.mp4`;
     const up=await db.storage.from('videos').upload(path,optimized,{contentType:'video/mp4',upsert:false,cacheControl:'31536000'});
     if(up.error)throw up.error;
     const pub=db.storage.from('videos').getPublicUrl(path).data?.publicUrl;
     if(!pub)throw Error('Could not create optimized video URL.');
     const upd=await db.from('videos').update({video_url:pub,width:v.width||null,height:v.height||null}).eq('id',v.id).eq('user_id',session.user.id);
     if(upd.error)throw upd.error;
     changed++;
     if(status)status.textContent=`Optimized ${changed} video${changed===1?'':'s'}…`;
   }
   if(status)status.textContent=changed?`Done. ${changed} video${changed===1?'':'s'} now use the optimized mobile version.`:'Your videos already look optimized.';
 }catch(e){if(status)status.textContent=e.message||'Optimization stopped. No original video was deleted.';}
 finally{button.disabled=false;}
}
export async function initializeCreatorDashboardController(){const root=document.querySelector('[data-creator-dashboard]');if(!root)return;if(root.dataset.loaded==='1')return;root.querySelector('[data-optimize-existing-videos]')?.addEventListener('click',optimizeExistingVideos);root.dataset.loaded='1';const metrics=root.querySelector('[data-dashboard-metrics]');if(metrics)metrics.innerHTML='<div class="studio-loading">Loading your creator analytics…</div>';try{const[overview,daily,audience]=await Promise.all([getCreatorDashboardOverview(30),getCreatorDailyAnalytics(7),getAudienceSnapshot(30)]);render(root,{...overview,days:daily},audience)}catch(e){console.warn('Creator Studio analytics unavailable',e);const c=root.querySelector('[data-dashboard-metrics]');if(c)c.innerHTML=`<div class="kv-error"><strong>Creator analytics are temporarily unavailable.</strong><p>${esc(e.message||'Please try again.')}</p></div>`}}
export function cleanupCreatorDashboardController(){const root=document.querySelector('[data-creator-dashboard]');if(root)root.dataset.loaded=''}
