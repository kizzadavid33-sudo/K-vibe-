import{db,SUPABASE_URL,SUPABASE_PUBLISHABLE_KEY}from'./supabase.js';
import{getCurrentUser,getSession}from'./auth.js';
import{requireAccountAccess}from'./account-access.js';
import{publishVideo}from'./videos.js';
import{createCameraEffects,FILTERS}from'./camera-effects.js';
let initialized=false,recorder=null,recorderStream=null,recordedBlob=null,effects=null,currentTusUpload=null,uploadAbortController=null,uploadCancelled=false;

export async function optimizeVideo(file,meta){
  // K-vibe does not depend on a remote FFmpeg worker anymore. Remote browser
  // workers can be blocked by CORS/COEP on Netlify and leave publishing stuck.
  // Keep this function as a compatibility no-op for callers.
  return file;
}

function readMetadata(file){return new Promise(resolve=>{const video=document.createElement('video');let done=false;const finish=meta=>{if(done)return;done=true;clearTimeout(timer);video.onloadedmetadata=null;video.onerror=null;try{URL.revokeObjectURL(video.src)}catch(_){}resolve(meta)};const timer=setTimeout(()=>finish({durationSeconds:null,width:null,height:null}),5000);video.preload='metadata';video.onloadedmetadata=()=>finish({durationSeconds:Number.isFinite(video.duration)?Math.round(video.duration*100)/100:null,width:video.videoWidth||null,height:video.videoHeight||null});video.onerror=()=>finish({durationSeconds:null,width:null,height:null});video.src=URL.createObjectURL(file)})}
function setStatus(message){const el=document.querySelector('[data-create-status]');if(el)el.textContent=message||''}
function renderEffects(){const host=document.querySelector('[data-camera-effects]');if(!host)return;host.innerHTML=Object.entries(FILTERS).map(([id,x])=>`<button type="button" data-effect="${id}">${x.name}</button>`).join('');host.hidden=false;host.querySelector('[data-effect="normal"]')?.classList.add('active')}
function syncEffectControls(){const c=effects?.controls||{};for(const [sel,val] of [['[data-effect-brightness]',c.brightness],['[data-effect-contrast]',c.contrast],['[data-effect-saturation]',c.saturation]]){const el=document.querySelector(sel);if(el&&val!=null)el.value=val}}
function stopCamera(){if(recorder&&recorder.state!=='inactive')recorder.stop();if(effects){effects.stop();effects=null}recorderStream=null;const preview=document.querySelector('[data-record-preview]');if(preview){preview.srcObject=null;preview.removeAttribute('src');preview.controls=false}}
async function publishFile(file,captionSelector='[data-upload-caption]',musicSelector='[data-upload-music]'){
  let path=null;
  uploadCancelled=false;
  try{
    requireAccountAccess('publish');
    const user=await getCurrentUser();
    if(!user)throw Error('Your K-vibe session has expired. Please sign in again, then return to Create.');
    if(!file)throw Error('Choose or record a video first.');
    if(!file.type.startsWith('video/'))throw Error('Please choose a video file.');
    if(file.size>45*1024*1024)throw Error(`This video is ${Math.round(file.size/1024/1024)} MB. K-vibe can currently upload videos up to 45 MB. Please choose a smaller video or shorten/compress it before uploading.`);

    setStatus('Preparing video…');
    const sourceMeta=await readMetadata(file);
    if(sourceMeta.durationSeconds&&sourceMeta.durationSeconds>900)throw Error('Video must be 15 minutes or shorter.');

    // Supabase rejects files above the project's Storage size ceiling. Do not
    // invoke a remote FFmpeg worker here: that path is unreliable in browsers.
    // Files within the ceiling upload directly/resumably and then publish.
    let playbackFile=file;
    let meta=sourceMeta;
    const mime=(playbackFile.type||file.type||'video/mp4').toLowerCase();
    const ext=mime.includes('webm')?'webm':mime.includes('quicktime')?'mov':'mp4';
    path=`${user.id}/${crypto.randomUUID()}.${ext}`;

    const session=await getSession();
    if(!session?.access_token)throw Error('Your session expired. Please sign in again.');

    // Supabase recommends TUS resumable uploads for files above 6 MB. Standard
    // POST uploads can hit the platform/request payload limit even though the
    // file itself is otherwise valid. Use the direct storage hostname for TUS.
    let upError=null;
    try{
      setStatus('Uploading video… 0%');
      const projectRef=new URL(SUPABASE_URL).hostname.split('.')[0];
      if(playbackFile.size>6*1024*1024){
        const endpoint=`https://${projectRef}.storage.supabase.co/storage/v1/upload/resumable`;
        const b64=v=>btoa(unescape(encodeURIComponent(v)));
        const metadata=[
          ['bucketName','videos'],
          ['objectName',path],
          ['contentType',mime],
          ['cacheControl','31536000']
        ].map(([k,v])=>`${k} ${b64(v)}`).join(',');
        const create=await fetch(endpoint,{method:'POST',headers:{
          'Authorization':`Bearer ${session.access_token}`,
          'apikey':SUPABASE_PUBLISHABLE_KEY,
          'Tus-Resumable':'1.0.0',
          'Upload-Length':String(playbackFile.size),
          'Upload-Metadata':metadata
        }});
        if(!create.ok)throw new Error(await create.text()||`Resumable upload could not start (${create.status}).`);
        const location=create.headers.get('Location')||create.headers.get('location');
        if(!location)throw new Error('Resumable upload did not return an upload URL.');
        let uploadUrl=location.startsWith('http')?location:new URL(location,endpoint).href;
        let offset=Number(create.headers.get('Upload-Offset')||0);
        const chunkSize=6*1024*1024;
        while(offset<playbackFile.size){
          if(uploadCancelled)throw Object.assign(new Error('Upload cancelled.'),{name:'AbortError'});
          const chunk=playbackFile.slice(offset,Math.min(offset+chunkSize,playbackFile.size));
          const next=await new Promise((resolve,reject)=>{
            const xhr=new XMLHttpRequest();
            uploadAbortController=xhr;
            xhr.open('PATCH',uploadUrl,true);
            xhr.setRequestHeader('Authorization',`Bearer ${session.access_token}`);
            xhr.setRequestHeader('apikey',SUPABASE_PUBLISHABLE_KEY);
            xhr.setRequestHeader('Tus-Resumable','1.0.0');
            xhr.setRequestHeader('Upload-Offset',String(offset));
            xhr.setRequestHeader('Content-Type','application/offset+octet-stream');
            xhr.upload.onprogress=e=>{
              if(e.lengthComputable){
                const percent=Math.max(0,Math.min(100,Math.round(((offset+e.loaded)/playbackFile.size)*100)));
                setStatus(`Uploading video… ${percent}%`);
              }
            };
            xhr.onload=()=>{
              if(xhr.status>=200&&xhr.status<300){
                const serverOffset=Number(xhr.getResponseHeader('Upload-Offset'));
                resolve(Number.isFinite(serverOffset)&&serverOffset>offset?serverOffset:offset+chunk.size);
              }else reject(new Error(xhr.responseText||`Resumable upload failed (${xhr.status}).`));
            };
            xhr.onerror=()=>reject(new Error('Network error while uploading the video.'));
            xhr.ontimeout=()=>reject(new Error('Upload timed out. Please try again.'));
            xhr.onabort=()=>reject(Object.assign(new Error('Upload cancelled.'),{name:'AbortError'}));
            xhr.send(chunk);
          });
          offset=next;
        }
        setStatus('Uploading video… 100%');
      }else{
        await new Promise((resolve,reject)=>{
          const xhr=new XMLHttpRequest();
          uploadAbortController=xhr;
          const endpoint=`${SUPABASE_URL}/storage/v1/object/videos/${path.split('/').map(encodeURIComponent).join('/')}`;
          xhr.open('POST',endpoint,true);
          xhr.setRequestHeader('Authorization',`Bearer ${session.access_token}`);
          xhr.setRequestHeader('apikey',SUPABASE_PUBLISHABLE_KEY);
          xhr.setRequestHeader('Content-Type',mime);
          xhr.setRequestHeader('x-upsert','false');
          xhr.setRequestHeader('cache-control','31536000');
          xhr.upload.onprogress=e=>{if(e.lengthComputable)setStatus(`Uploading video… ${Math.round((e.loaded/e.total)*100)}%`)};
          xhr.onload=()=>xhr.status>=200&&xhr.status<300?resolve():reject(new Error(xhr.responseText||`Storage upload failed (${xhr.status}).`));
          xhr.onerror=()=>reject(new Error('Network error while uploading the video.'));
          xhr.ontimeout=()=>reject(new Error('Upload timed out. Please try again.'));
          xhr.onabort=()=>reject(Object.assign(new Error('Upload cancelled.'),{name:'AbortError'}));
          xhr.send(playbackFile);
        });
      }
      setStatus('Upload complete. Publishing…');
    }catch(e){upError=e}
    if(upError){if(upError.name==='AbortError'||uploadCancelled)throw Error('Upload cancelled.');throw Error(`Video upload failed: ${upError.message||upError}`)}
    if(uploadCancelled)throw Error('Upload cancelled.');

    const{data:url}=db.storage.from('videos').getPublicUrl(path);
    if(!url?.publicUrl)throw Error('The video uploaded, but its public URL could not be created.');
    setStatus('Publishing to K-vibe…');
    let result;
    try{
      result=await publishVideo({videoUrl:url.publicUrl,caption:document.querySelector(captionSelector)?.value||'',musicName:document.querySelector(musicSelector)?.value||'',durationSeconds:meta.durationSeconds,width:meta.width,height:meta.height});
    }catch(e){
      const msg=e?.message||e?.details||e?.hint||'Unknown publish error';
      throw Error(`Upload reached 100%, but publishing failed: ${msg}`);
    }
    dispatchEvent(new CustomEvent('k-vibe:video-published',{detail:{video:result}}));
    return result;
  }catch(e){
    if(path)await db.storage.from('videos').remove([path]).catch(()=>{});
    throw e;
  }finally{currentTusUpload=null;uploadAbortController=null}
}


let musicCatalog=[];
let selectedMusic={upload:null,record:null};

function musicText(row){return [row.title,row.artist,row.genre,row.mood].filter(Boolean).join(' ').toLowerCase()}
function renderMusicPicker(kind, query=''){
  const list=document.querySelector(`[data-music-list="${kind}"]`);
  if(!list)return;
  const q=(query||'').trim().toLowerCase();
  const rows=musicCatalog.filter(x=>!q||musicText(x).includes(q));
  if(!rows.length){list.innerHTML='<p class="muted">No matching music found.</p>';return}
  list.innerHTML=rows.map(x=>{
    const selected=selectedMusic[kind]?.id===x.id;
    const safeTitle=String(x.title||'Untitled').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    const safeArtist=String(x.artist||'K-vibe Music').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    const safeGenre=String(x.genre||x.mood||'').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    return `<div class="music-item${selected?' selected':''}" data-music-id="${x.id}"><div class="music-cover">♪</div><div class="music-info"><strong>${safeTitle}</strong><small>${safeArtist}${safeGenre?' · '+safeGenre:''}</small></div><button type="button" class="music-preview" data-music-preview="${x.id}">▶</button><button type="button" class="music-use" data-music-use="${x.id}">${selected?'Used':'Use'}</button></div>`;
  }).join('');
}
async function loadMusicCatalog(){
  try{
    const {data,error}=await db.from('music_catalog').select('id,title,artist,audio_url,cover_url,genre,mood,duration_seconds,license_type,attribution_required,attribution_text').eq('is_active',true).order('title').limit(100);
    if(error)throw error;
    musicCatalog=data||[];
    renderMusicPicker('upload');renderMusicPicker('record');
  }catch(err){
    console.warn('Music catalog unavailable:',err);
    document.querySelectorAll('[data-music-list]').forEach(el=>el.innerHTML='<p class="muted">Music catalog could not be loaded. Check your connection and try again.</p>');
  }
}
function applySelectedMusic(kind,row){
  selectedMusic[kind]=row||null;
  const input=document.querySelector(kind==='upload'?'[data-upload-music]':'[data-record-music]');
  if(input)input.value=row?.title||'';
  renderMusicPicker(kind,document.querySelector(`[data-music-search="${kind}"]`)?.value||'');
}
function wireMusicPicker(kind){
  const search=document.querySelector(`[data-music-search="${kind}"]`);
  search?.addEventListener('input',()=>renderMusicPicker(kind,search.value));
  document.querySelector(`[data-music-clear="${kind}"]`)?.addEventListener('click',()=>{applySelectedMusic(kind,null);if(search)search.value='';});
  document.querySelector(`[data-music-list="${kind}"]`)?.addEventListener('click',e=>{
    const preview=e.target.closest('[data-music-preview]');
    if(preview){
      const row=musicCatalog.find(x=>x.id===preview.dataset.musicPreview);
      if(!row?.audio_url){setStatus('This track has no preview audio available.');return;}
      let audio=document.getElementById('kvibe-music-preview');
      if(!audio){audio=document.createElement('audio');audio.id='kvibe-music-preview';audio.preload='none';document.body.appendChild(audio)}
      if(audio.src===row.audio_url&&!audio.paused){audio.pause();preview.textContent='▶';return}
      document.querySelectorAll('[data-music-preview]').forEach(b=>b.textContent='▶');
      audio.src=row.audio_url; audio.volume=.8; audio.play().then(()=>{preview.textContent='❚❚'}).catch(()=>setStatus('Tap Preview again to start the music preview.'));
      audio.onended=()=>{document.querySelectorAll('[data-music-preview]').forEach(b=>b.textContent='▶')};
      return;
    }
    const use=e.target.closest('[data-music-use]');
    if(use){const row=musicCatalog.find(x=>x.id===use.dataset.musicUse);if(row)applySelectedMusic(kind,row)}
  });
}

function cancelUpload(){
  uploadCancelled=true;
  if(currentTusUpload){try{currentTusUpload.abort(true)}catch(_){}currentTusUpload=null}
  if(uploadAbortController){try{uploadAbortController.abort()}catch(_){}uploadAbortController=null}
  setStatus('Upload cancelled.');
  document.querySelector('[data-upload-cancel]')?.setAttribute('hidden','');
  document.querySelector('[data-create-submit]')?.removeAttribute('disabled');
}

function cancelRecording(){
  if(recorder&&recorder.state!=='inactive'){
    recorder.onstop=null;
    try{recorder.stop()}catch(_){}
  }
  if(recorderStream)recorderStream.getTracks().forEach(t=>t.stop());
  if(effects){effects.stop();effects=null}
  recorder=null;recorderStream=null;recordedBlob=null;
  const preview=document.querySelector('[data-record-preview]');
  if(preview){preview.srcObject=null;preview.removeAttribute('src');preview.controls=false}
  document.querySelector('[data-record-stop]')?.setAttribute('hidden','');
  document.querySelector('[data-record-cancel]')?.setAttribute('hidden','');
  document.querySelector('[data-record-start]')?.removeAttribute('hidden');
  document.querySelector('[data-record-publish]')?.setAttribute('disabled','');
  setStatus('Recording cancelled.');
}

async function startRecording(){
  if(!window.isSecureContext)throw Error('Camera recording requires HTTPS. Open the K-vibe Netlify link in Chrome.');
  if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder)throw Error('Your browser cannot record video. Please use the latest Chrome.');
  stopCamera(); recordedBlob=null;
  let raw=null;
  try{
    raw=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:{ideal:1280},height:{ideal:720}},audio:true});
    recorderStream=raw;
    const preview=document.querySelector('[data-record-preview]');
    if(preview){preview.srcObject=raw;preview.muted=true;preview.playsInline=true;await preview.play().catch(()=>{})}
    // Filters are optional. Never let a canvas/filter failure prevent recording.
    try{effects=createCameraEffects();const processed=await effects.start(raw);if(processed&&processed.getVideoTracks().length){recorderStream=processed;if(preview){preview.srcObject=processed;await preview.play().catch(()=>{})}renderEffects();syncEffectControls();document.querySelector('[data-camera-controls]')?.removeAttribute('hidden')}}catch(filterErr){console.warn('Optional camera effects unavailable; recording raw camera stream.',filterErr);effects=null;recorderStream=raw}
    const preferred=['video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm'];
    const mime=preferred.find(x=>MediaRecorder.isTypeSupported(x))||'';
    const chunks=[];
    recorder=new MediaRecorder(recorderStream,mime?{mimeType:mime}:undefined);
    recorder.ondataavailable=e=>{if(e.data?.size)chunks.push(e.data)};
    recorder.onstop=()=>{recordedBlob=new Blob(chunks,{type:recorder?.mimeType||'video/webm'});const url=URL.createObjectURL(recordedBlob);if(preview){preview.srcObject=null;preview.src=url;preview.controls=true;preview.muted=false}document.querySelector('[data-record-publish]')?.removeAttribute('disabled');setStatus('Recording ready. Add a caption and publish it.');if(effects){effects.stop();effects=null}recorderStream=null};
    recorder.start(250);
    document.querySelector('[data-record-start]')?.setAttribute('hidden','');document.querySelector('[data-record-stop]')?.removeAttribute('hidden');document.querySelector('[data-record-cancel]')?.removeAttribute('hidden');setStatus('Recording…');
  }catch(err){if(raw)raw.getTracks().forEach(t=>t.stop());if(effects){effects.stop();effects=null}recorder=null;recorderStream=null;throw new Error(err?.name==='NotAllowedError'?'Camera/microphone permission was denied. Allow both permissions in Chrome and try again.':err?.message||'Could not start recording.')}}

export function initializeCreateController(){
  if(initialized)return;
  const form=document.querySelector('[data-create]'); if(!form)return;
  initialized=true;
  const input=form.querySelector('[data-video-file-input]'),uploadPanel=form.querySelector('[data-upload-panel]'),recordPanel=form.querySelector('[data-record-panel]'),livePanel=document.querySelector('[data-live-panel]');
  const showUpload=()=>{uploadPanel?.removeAttribute('hidden');recordPanel?.setAttribute('hidden','');livePanel?.setAttribute('hidden','');stopCamera();document.querySelector('[data-upload-cancel]')?.setAttribute('hidden','');setStatus('')};
  const showRecord=()=>{recordPanel?.removeAttribute('hidden');uploadPanel?.setAttribute('hidden','');livePanel?.setAttribute('hidden','');renderEffects();setStatus('')};
  const showLive=()=>{uploadPanel?.setAttribute('hidden','');recordPanel?.setAttribute('hidden','');livePanel?.removeAttribute('hidden');stopCamera();setStatus('')};
  const uploadTab=form.querySelector('[data-create-upload-tab]'),recordTab=form.querySelector('[data-create-record-tab]'),liveTab=form.querySelector('[data-create-live-tab]');
  uploadTab?.addEventListener('click',e=>{e.preventDefault();showUpload()});
  recordTab?.addEventListener('click',e=>{e.preventDefault();showRecord()});
  liveTab?.addEventListener('click',e=>{e.preventDefault();showLive()});
  form.querySelector('[data-record-start]')?.addEventListener('click',async e=>{e.preventDefault();try{await startRecording()}catch(err){setStatus(err.message||'Could not start the camera.')}});
  form.querySelector('[data-record-stop]')?.addEventListener('click',e=>{e.preventDefault();if(recorder&&recorder.state!=='inactive')recorder.stop();e.currentTarget.setAttribute('hidden','');form.querySelector('[data-record-start]')?.removeAttribute('hidden')});
  form.querySelector('[data-record-publish]')?.addEventListener('click',async e=>{e.preventDefault();if(!recordedBlob)return;const b=e.currentTarget;b.disabled=true;try{await publishFile(new File([recordedBlob],'k-vibe-recording.webm',{type:recordedBlob.type||'video/webm'}),'[data-record-caption]','[data-record-music]');form.reset();recordedBlob=null;setStatus('Published successfully.')}catch(err){setStatus(err.message||'Publish failed.')}finally{b.disabled=false}});
  form.addEventListener('click',e=>{const b=e.target.closest?.('[data-effect]');if(!b||!form.contains(b))return;e.preventDefault();if(effects){effects.setFilter(b.dataset.effect);form.querySelectorAll('[data-effect]').forEach(x=>x.classList.toggle('active',x===b));setStatus(`${b.textContent} filter selected.`)}else{setStatus('Start the camera first, then choose a filter.')}});
  form.querySelector('[data-camera-switch]')?.addEventListener('click',async()=>{if(!effects)return;try{await effects.switchCamera();setStatus('Camera switched.')}catch(err){setStatus(err.message||'Could not switch camera.')}});
  form.querySelector('[data-effect-brightness]')?.addEventListener('input',e=>effects?.setBrightness(e.target.value));form.querySelector('[data-effect-contrast]')?.addEventListener('input',e=>effects?.setContrast(e.target.value));form.querySelector('[data-effect-saturation]')?.addEventListener('input',e=>effects?.setSaturation(e.target.value));
  form.addEventListener('submit',async e=>{e.preventDefault();const file=input?.files?.[0],submit=form.querySelector('[data-create-submit]'),cancel=form.querySelector('[data-upload-cancel]');if(submit)submit.disabled=true;if(cancel)cancel.removeAttribute('hidden');try{await publishFile(file);form.reset();setStatus('Published successfully.')}catch(err){setStatus(err?.message||'Video could not be uploaded or published.')}finally{if(submit)submit.disabled=false;if(cancel)cancel.setAttribute('hidden','')}});
  input?.addEventListener('change',()=>{const file=input.files?.[0];if(file){setStatus(`${file.name} selected. Tap Publish video.`);document.querySelector('[data-upload-cancel]')?.setAttribute('hidden','')}});
  form.querySelector('[data-upload-cancel]')?.addEventListener('click',e=>{e.preventDefault();cancelUpload();input.value='';});
  form.querySelector('[data-record-cancel]')?.addEventListener('click',e=>{e.preventDefault();cancelRecording();});
  wireMusicPicker('upload');
  wireMusicPicker('record');
  loadMusicCatalog();
  showUpload();
}

export function cleanupCreateController(){stopCamera();initialized=false;recordedBlob=null}
