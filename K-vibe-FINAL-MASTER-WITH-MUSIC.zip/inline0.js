(function(){
  var hero=document.querySelector('[data-welcome-hero]');
  var auth=document.querySelector('[data-auth]');
  if(!hero||!auth)return;
  hero.hidden=false;
  auth.hidden=true;
  window.setTimeout(function(){
    hero.hidden=true;
    auth.hidden=false;
    var mode=auth.querySelector('[data-auth-mode]');
    if(mode)mode.value='signin';
    var title=auth.querySelector('[data-auth-title]');
    if(title)title.textContent='Sign in to K-vibe';
    var submit=auth.querySelector('[data-auth-submit]');
    if(submit)submit.textContent='Sign in';
    var toggle=auth.querySelector('[data-auth-toggle]');
    if(toggle)toggle.textContent='Sign up';
    var username=auth.querySelector('[data-auth-username]');
    var display=auth.querySelector('[data-auth-display-name]');
    if(username){username.hidden=true;username.required=false;}
    if(display)display.hidden=true;
    var password=auth.querySelector('[data-auth-password]');
    if(password)password.autocomplete='current-password';
    window.scrollTo(0,0);
  },900);
})();
